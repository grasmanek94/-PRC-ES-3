#ifndef __CAR_H
#define __CAR_H

#include <string>
using namespace std;

// TODO: your class definition goes here

#endif