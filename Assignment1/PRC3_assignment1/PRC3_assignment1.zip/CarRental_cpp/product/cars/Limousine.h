#ifndef __LIMOUSINE_H
#define __LIMOUSINE_H

#include "Car.h"

// TODO: your class definition goes here

#endif