#define CONSUMER

#include "producer.c"